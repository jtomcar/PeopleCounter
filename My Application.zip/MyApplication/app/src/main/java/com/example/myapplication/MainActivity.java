package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.*;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    //private static final UUID UUID = ;
    public static Boolean bluetoothActive = false;
    private ArrayList<BluetoothDevice> deviceList = new ArrayList<BluetoothDevice>();
    BluetoothAdapter bluetooth = BluetoothAdapter.getDefaultAdapter();

    Button connectButton;
    Button disconnectButton;
    Button forwardButton;
    Button backwardButton;
    Button turnLeftForwardButton;
    Button turnRightForwardButton;
    TextView statusLabel;
    BluetoothSocket btSocket;
    InputStream inputStream;
    OutputStream outputStream;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        connectButton = (Button) findViewById(R.id.buttonActive);
        disconnectButton = (Button) findViewById(R.id.buttonDesactive);
        forwardButton = (Button) findViewById(R.id.buttonForward);
        backwardButton= (Button) findViewById(R.id.buttonBack);
        turnLeftForwardButton= (Button) findViewById(R.id.buttonLeft);
        turnRightForwardButton= (Button) findViewById(R.id.buttonRight);
        statusLabel = (TextView) findViewById(R.id.textConexion);
    }

    public void onClickForwardButton(View view){
        forward();
    }
    public void onClickStopButton(View view){
        stop();
    }
    public void onClickTurnLeftForwardButton(View view){
        left();
    }
    public void onClickTurnRightForwardButton(View view){
        right();
    }

    public void onClickConnectButton(View view){

        if (bluetooth.isEnabled()){
            String address = bluetooth.getAddress();
            String name = bluetooth.getName();
            //Mostramos la datos en pantalla (The information is shown in the screen)
            Toast.makeText(getApplicationContext(),"Bluetooth ENABLED:"+name+":"+address,
                    Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(getApplicationContext(),"Bluetooth NOT enabled",
                    Toast.LENGTH_SHORT).show();
        }
        startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE),1);
        bluetoothActive = true;
        Toast.makeText(getApplicationContext(),
                "Bluetooth active" + bluetoothActive,
                Toast.LENGTH_SHORT).show();
        startDiscovery();
        statusLabel.setText("Connect pressed");
    }
    public void onClickDissconnectedButton(View view){
        if(bluetoothActive){
            bluetooth.disable();
        }
        statusLabel.setText("Connect down");
    }

    BroadcastReceiver discoveryResult = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            //Guardamos el nombre del dispositivo descubierto
            String remoteDeviceName = intent.getStringExtra(BluetoothDevice.EXTRA_NAME);
            //Guardamos el objeto Java del dispositivo descubierto, para poderconectar.
            BluetoothDevice remoteDevice =  intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
            //Leemos la intensidad de la radio con respecto a este dispositivo bluetooth
            int rssi = intent.getShortExtra(BluetoothDevice.EXTRA_RSSI,Short.MIN_VALUE);
            //Guardamos el dispositivo encontrado en la lista
            deviceList.add(remoteDevice);

            statusLabel.setText("Discovered "+ remoteDeviceName+"\nRSSI "+ rssi + "dBm");
            //Mostramos el evento en el Log
            Log.d("MyFirstApp", "Discovered "+ remoteDeviceName);
            Log.d("MyFirstApp", "RSSI "+ rssi + "dBm");

            try {
                if (remoteDevice != null && remoteDeviceName.equals("Aquaris")) {
                    //   Log.d("onReceive", "Discovered SUM_SCH3:connecting");
                    statusLabel.setText("Discovered SUM_SCH3:connecting");
                    connect(remoteDevice);
                }
            } catch (Exception ex) {
                Log.d("MyFirstApp", "Recogida excepción");

            }


        }
    };




    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) //Bluetooth permission request code
            if (resultCode == RESULT_OK) {
                Toast.makeText(getApplicationContext(), "User Enabled Bluetooth",
                        Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getApplicationContext(), "User Did not enable Bluetooth",
                        Toast.LENGTH_SHORT).show();
            }
    }
    private void startDiscovery(){
        if (bluetoothActive){
            //Borramos la lista de dispositivos anterior
            deviceList.clear();
            //Activamos un Intent Android que avise cuando se encuentre un dispositivo
            //NOTA: <<discoveryResult>> es una clase <<callback>> que describiremos en el siguiente paso
            registerReceiver(discoveryResult, new IntentFilter(BluetoothDevice.ACTION_FOUND));
            //Ponemos el adaptador bluetooth en modo <<Discovery>>
            checkBTPermissions();
            bluetooth.startDiscovery();
        }
    }

    public void checkBTPermissions(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            switch (ContextCompat.checkSelfPermission(getBaseContext(),
                    Manifest.permission.ACCESS_COARSE_LOCATION)) {
                case PackageManager.PERMISSION_DENIED:
                    if (ContextCompat.checkSelfPermission(getBaseContext(),
                            Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                        this.requestPermissions(new
                                String[]{
                                        Manifest.permission.ACCESS_FINE_LOCATION,
                                        Manifest.permission.ACCESS_COARSE_LOCATION},
                                1001);
                    }
                    break;
                case PackageManager.PERMISSION_GRANTED:
                    break;
                default:
                    throw new IllegalStateException("Unexpected value: " + ContextCompat.checkSelfPermission(getBaseContext(),
                            Manifest.permission.ACCESS_COARSE_LOCATION));
            }
        }
    }

    protected void connect(BluetoothDevice device) {

        try {
           // btSocket = device.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"));
            btSocket.connect();
            Log.d("connect", "Client connected");
            statusLabel.setText("Client connected");
            inputStream = btSocket.getInputStream();
            outputStream = btSocket.getOutputStream();
        }catch (Exception e) {
            Log.e("ERROR: connect", ">>", e);
        }

       /* device = bluetooth.getRemoteDevice("30:85:A9:51:1A:A6");
        connect(device);*/
    }



    // Movimiento del robot
    public void forward() {
        try {
            String tmpStr = "W";
            byte bytes[] = tmpStr.getBytes();
            if (outputStream != null) outputStream.write(bytes);
            if (outputStream != null) outputStream.flush();
        } catch (Exception e) {
            Log.e("forward", "ERROR:" + e);
        }
    }

    public void left() {
        try {
            String tmpStr = "L";
            byte bytes[] = tmpStr.getBytes();
            if (outputStream != null) outputStream.write(bytes);
            if (outputStream != null) outputStream.flush();
        } catch (Exception e) {
            Log.e("left", "ERROR:" + e);
        }
    }

    public void right() {
        try {
            String tmpStr = "R";
            byte bytes[] = tmpStr.getBytes();
            if (outputStream != null) outputStream.write(bytes);
            if (outputStream != null) outputStream.flush();
        } catch (Exception e) {
            Log.e("right", "ERROR:" + e);
        }
    }

    public void stop() {
        try {
            String tmpStr = "S";
            byte bytes[] = tmpStr.getBytes();
            if (outputStream != null) outputStream.write(bytes);
            if (outputStream != null) outputStream.flush();
        } catch (Exception e) {
            Log.e("stop", "ERROR:" + e);
        }
    }



}